(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_d901fa._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_d901fa._.js",
  "chunks": [
    "static/chunks/node_modules_next_15251b._.js",
    "static/chunks/node_modules_jspdf_dist_jspdf_es_min_c277e7.js",
    "static/chunks/node_modules_html2canvas_dist_html2canvas_3938cd.js",
    "static/chunks/node_modules_1b6742._.js",
    "static/chunks/_f081cb._.js",
    "static/chunks/node_modules_b9f952._.js"
  ],
  "source": "dynamic"
});
