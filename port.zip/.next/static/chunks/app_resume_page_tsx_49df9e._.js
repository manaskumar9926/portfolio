(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_resume_page_tsx_49df9e._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_resume_page_tsx_49df9e._.js",
  "chunks": [
    "static/chunks/_484c2e._.js"
  ],
  "source": "dynamic"
});
