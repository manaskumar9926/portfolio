(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_tsx_61af54._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_tsx_61af54._.js",
  "chunks": [
    "static/chunks/[root of the server]__2bdfad._.css",
    "static/chunks/node_modules_a8891e._.js",
    "static/chunks/_1cbb49._.js"
  ],
  "source": "dynamic"
});
