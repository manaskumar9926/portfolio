(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_work_page_tsx_d901fa._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_work_page_tsx_d901fa._.js",
  "chunks": [
    "static/chunks/node_modules_8931ea._.js",
    "static/chunks/_aec86f._.js"
  ],
  "source": "dynamic"
});
