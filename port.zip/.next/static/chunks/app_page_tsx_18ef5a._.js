(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_18ef5a._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_18ef5a._.js",
  "chunks": [
    "static/chunks/node_modules_jspdf_dist_jspdf_es_min_c277e7.js",
    "static/chunks/node_modules_html2canvas_dist_html2canvas_3938cd.js",
    "static/chunks/node_modules_html2pdf_js_dist_html2pdf_6c43fb.js",
    "static/chunks/node_modules_1b6742._.js",
    "static/chunks/_f081cb._.js",
    "static/chunks/node_modules_05e44a._.js"
  ],
  "source": "dynamic"
});
