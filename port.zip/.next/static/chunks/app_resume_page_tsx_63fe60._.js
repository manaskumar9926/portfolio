(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_resume_page_tsx_63fe60._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_resume_page_tsx_63fe60._.js",
  "chunks": [
    "static/chunks/node_modules_08a752._.js",
    "static/chunks/_484c2e._.js",
    "static/chunks/node_modules_bce18a._.js"
  ],
  "source": "dynamic"
});
