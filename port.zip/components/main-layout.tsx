'use client'

import ChildrenInterface from '@/interfaces/children-interface'
import Image from 'next/image'
import Link from 'next/link'
import React, { FC } from 'react'
import { usePathname } from 'next/navigation'

const MainLayout: FC<ChildrenInterface> = ({ children }) => {
  const skills = [
    "JavaScript", "React.js", "Next.js", "Node.js",
    "Express", "MongoDB", "AWS Cloud", "GIT",
    "Redis", "Docker", "HTML", "CSS", "TailwindCSS"
  ]

  const pathname = usePathname()

  const navLinks = [
    { href: '/resume', label: 'RESUME', icon: 'ri-file-text-line' },
    { href: '/work', label: 'PORTFOLIO', icon: 'ri-code-block' },
    { href: '/contact', label: 'CONTACT', icon: 'ri-book-3-line' },
  ]

  return (
    <>
      {/* Background Image Header */}
      <div className="w-full h-80 bg-[url('/images/header.jpeg')] bg-cover bg-center"></div>

      {/* Profile Header Section */}
      <section className="w-full max-w-screen-xl mx-auto px-4 pb-6">
        <header className="relative -mt-36 md:-mt-20 bg-white rounded-2xl shadow grid lg:grid-cols-2 gap-6 p-6">
          
          {/* Left Section */}
          <div className="flex flex-col lg:flex-row items-center lg:items-start gap-6">
            <div className="w-40 rounded-[35px] p-1 bg-white shadow">
              <Image
                alt="Manas Kumar"
                width={200}
                height={200}
                src="/images/profile.jpeg"
                className="rounded-[35px]"
                style={{ color: 'transparent' }}
                priority
              />
            </div>
            <div className="text-center lg:text-left">
              <h1 className="text-2xl font-bold text-gray-600">Manas Kumar</h1>
              <p className="text-sm text-gray-500">Fullstack Web Developer at Techsunset</p>
              <div className="flex justify-center lg:justify-start gap-3 mt-2">
                <a href="https://www.linkedin.com/in/manas-kumar-6a831b1a0/" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn">
                  <i className="ri-linkedin-fill text-blue-600 text-xl"></i>
                </a>
              </div>
            </div>
          </div>

          {/* Contact Info */}
          <div className="grid sm:grid-cols-2 gap-4">
            {[
              { label: 'EMAIL', value: 'kumarmanas2001@gmail.com' },
              { label: 'BIRTHDAY', value: '07 July 2001' },
              { label: 'PHONE', value: '+91 7294947294' },
              { label: 'LOCATION', value: 'Noida, India' },
            ].map((item) => (
              <div key={item.label}>
                <span className="text-xs font-medium text-slate-400">{item.label}</span>
                <p className="text-sm text-slate-600">{item.value}</p>
              </div>
            ))}
          </div>
        </header>
      </section>

      {/* Navigation & Skills */}
      <section className="w-full max-w-screen-xl mx-auto px-4 flex flex-col lg:flex-row gap-6">
        
        {/* Sidebar Navigation */}
        <aside className="w-full lg:w-64 bg-white rounded-2xl shadow p-4">
          <ul className="flex lg:flex-col justify-center lg:justify-start gap-4">
            {navLinks.map(link => (
              <li key={link.href} className={`${pathname === link.href ? 'bg-gradient-to-r from-[#3086FF] to-[#304CFD]' : 'bg-slate-100'} p-3 rounded-xl w-full`}>
                <Link
                  href={link.href}
                  className={`flex flex-col items-center gap-1 text-sm font-medium ${pathname === link.href ? 'text-white' : 'text-slate-600'}`}
                >
                  <i className={`${link.icon} text-xl`}></i>
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
        </aside>

        {/* Skills */}
        <div className="w-full bg-white rounded-2xl shadow p-6">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b pb-4">
            <h2 className="text-xl font-bold text-slate-600">SKILLS</h2>
            <button className="mt-4 md:mt-0 bg-gradient-to-r from-[#3086FF] to-[#304CFD] text-white px-4 py-2 rounded text-sm">
              <i className="ri-download-line mr-1"></i>
              Download CV
            </button>
          </div>
          <ul className="flex flex-wrap gap-2 mt-4">
            {skills.map(skill => (
              <li key={skill} className="px-4 py-2 border rounded-full text-sm text-slate-600">
                {skill}
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* Children Route Content */}
      <section className="w-full max-w-screen-xl mx-auto px-4 my-8">
        {children}
      </section>

      {/* WhatsApp Floating Button */}
      <a
        href="https://wa.me/917294947294"
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-50 bg-green-500 hover:bg-green-600 text-white p-3 rounded-full shadow-lg"
        aria-label="Chat on WhatsApp"
      >
        <i className="ri-whatsapp-line text-2xl"></i>
      </a>
    </>
  )
}

export default MainLayout
