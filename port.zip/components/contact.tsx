// app/components/Contact.tsx
'use client'

import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Button } from '@/components/ui/button'
import { notification } from 'antd'

// 1. Validation Schema
const contactSchema = z.object({
  fullname: z.string().min(2, 'Full name is required'),
  email: z.string().email('Enter a valid email'),
  message: z.string().min(10, 'Message must be at least 10 characters'),
})

type ContactFormData = z.infer<typeof contactSchema>

const Contact = () => {
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm<ContactFormData>({
    resolver: zodResolver(contactSchema),
  })

  const onSubmit = (data: ContactFormData) => {
    console.log('Form submitted:', data)
    notification.success({
      message: 'Message Sent',
      description: 'Thank you! We will contact you soon.',
    })
    reset()
  }

  return (
    <section className="px-4 py-10 md:px-10 max-w-4xl mx-auto">
      <div className="bg-white rounded-2xl shadow-lg p-6 md:p-10">
        <h2 className="text-2xl md:text-3xl font-bold mb-6 text-gray-800">Contact Us</h2>

        <form onSubmit={handleSubmit(onSubmit)} className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Fullname */}
          <div className="col-span-1">
            <Input placeholder="Full Name" {...register('fullname')} />
            {errors.fullname && <p className="text-sm text-red-500 mt-1">{errors.fullname.message}</p>}
          </div>

          {/* Email */}
          <div className="col-span-1">
            <Input type="email" placeholder="Email Address" {...register('email')} />
            {errors.email && <p className="text-sm text-red-500 mt-1">{errors.email.message}</p>}
          </div>

          {/* Message */}
          <div className="col-span-1 md:col-span-2">
            <Textarea placeholder="Your message..." rows={6} {...register('message')} />
            {errors.message && <p className="text-sm text-red-500 mt-1">{errors.message.message}</p>}
          </div>

          {/* Submit */}
          <div className="col-span-1 md:col-span-2 flex justify-end">
            <Button
              type="submit"
              className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white w-full md:w-auto"
            >
              Send Message
            </Button>
          </div>
        </form>
      </div>
    </section>
  )
}

export default Contact
