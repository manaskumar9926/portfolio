"use client"
import React, { useEffect, useRef } from "react"
import Image from "next/image"
import jsPDF from "jspdf"
import html2canvas from "html2canvas"

const Resume = () => {
  const resumeRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const generatePDF = async () => {
      if (resumeRef.current) {
        const canvas = await html2canvas(resumeRef.current, {
          scale: 2,
          useCORS: true,
        })
        const imgData = canvas.toDataURL("image/png")
        const pdf = new jsPDF("p", "mm", "a4")
        const pdfWidth = pdf.internal.pageSize.getWidth()
        const pdfHeight = (canvas.height * pdfWidth) / canvas.width

        pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight)
        pdf.save("Manas_Kumar_Resume.pdf")
      }
    }

    generatePDF()
  }, [])

  return (
    <div className="w-full max-w-6xl mx-auto px-4 py-10">
      <section
        ref={resumeRef}
        className="bg-white rounded-2xl shadow p-6 text-black"
        style={{
          width: "210mm",
          minHeight: "297mm",
          margin: "auto",
        }}
      >
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          {/* Left Sidebar */}
          <div className="bg-slate-100 px-4 py-8 flex flex-col items-center gap-y-10 lg:col-span-2 rounded-xl">
            {/* Profile Image */}
            <div className="w-[160px] h-[160px] border-[6px] border-white bg-white flex justify-center items-center rounded-full overflow-hidden">
              <Image
                alt="Manas Kumar"
                src="/images/profile.jpeg"
                width={160}
                height={160}
                className="object-cover"
              />
            </div>

            {/* Name (Mobile) */}
            <div className="text-center lg:hidden">
              <h1 className="text-2xl font-bold text-gray-800">MANAS KUMAR</h1>
              <p className="text-gray-500 text-sm">Fullstack Web Developer at Techsunset</p>
            </div>

            {/* Contact */}
            <div className="w-full">
              <h2 className="bg-gray-600 text-white text-center py-1 font-semibold">CONTACT</h2>
              <ul className="my-4 space-y-2 text-center text-sm text-slate-600">
                <li>📞 +91 7294947294</li>
                <li>📧 kumarmanas2001@gmail.com</li>
                <li>📍 Noida 110025</li>
              </ul>
            </div>

            {/* Education */}
            <div className="w-full">
              <h2 className="bg-gray-600 text-white text-center py-1 font-semibold">EDUCATION</h2>
              <ul className="my-4 space-y-3 text-center text-sm">
                <li>
                  <strong>MERN Stack Web Development</strong><br />
                  Wap Institution<br />
                  <small>2020 - 2021</small>
                </li>
                <li>
                  <strong>Bachelor of Technology</strong><br />
                  Quantum University<br />
                  <small>2019 - 2023</small>
                </li>
              </ul>
            </div>

            {/* Languages */}
            <div className="w-full">
              <h2 className="bg-gray-600 text-white text-center py-1 font-semibold">LANGUAGES</h2>
              <div className="flex gap-2 justify-center my-4">
                <span className="bg-white text-sm px-4 py-1 rounded-full">English</span>
                <span className="bg-white text-sm px-4 py-1 rounded-full">Hindi</span>
              </div>
            </div>
          </div>

          {/* Right Content */}
          <div className="w-full px-2 sm:px-4 py-6 lg:col-span-3">
            {/* Name (Desktop) */}
            <div className="hidden lg:block mb-6">
              <h1 className="text-5xl font-bold">MANAS</h1>
              <h3 className="text-4xl font-medium">KUMAR</h3>
              <p className="text-gray-600">Fullstack Web Developer at Techsunset</p>
            </div>

            {/* Skills */}
            <div className="mt-6">
              <h2 className="bg-gray-600 text-white px-4 py-1 font-semibold">SKILLS</h2>
              <div className="flex flex-wrap gap-2 mt-4 text-sm">
                {[
                  "JavaScript", "React.js", "Next.js", "Node.js", "Express", "MongoDB",
                  "AWS Cloud", "GIT", "Redis", "Docker", "HTML", "CSS", "TailwindCSS"
                ].map(skill => (
                  <span
                    key={skill}
                    className="bg-white border px-3 py-1 rounded-full text-slate-700"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>

            {/* Work Experience */}
            <div className="mt-10">
              <h2 className="bg-gray-600 text-white px-4 py-1 font-semibold">WORK EXPERIENCE</h2>
              <div className="mt-4 space-y-2 text-sm text-slate-700">
                <h3 className="font-bold">Fullstack Web Developer @ Techsunset</h3>
                <small className="text-slate-500">2021 - 2024</small>
                <ul className="list-disc pl-5 mt-2 space-y-1">
                  <li><strong>Developed Web Apps:</strong> MERN stack websites with performance in mind.</li>
                  <li><strong>API Integration:</strong> REST APIs with Node.js, Express, MongoDB.</li>
                  <li><strong>Frontend:</strong> Responsive UIs with React and Next.js.</li>
                </ul>
              </div>
            </div>

            {/* Projects */}
            <div className="mt-6">
              <h2 className="bg-gray-600 text-white px-4 py-1 font-semibold">PROJECTS</h2>
              <div className="grid grid-cols-2 gap-4 mt-4 text-sm text-slate-800">
                {[
                  "Nurserylive", "Naadi Interiors", "Studio Avt",
                  "Cube Decors", "Click2call", "Oh Yes World"
                ].map(project => (
                  <div key={project} className="font-semibold">{project}</div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default Resume
