import { ReactNode } from "react";

interface ChildrenInterface {
    children: ReactNode
}

export default ChildrenInterface