import Resume from '@/components/resume'
import React from 'react'

const ResumeRouter = () => {
  return (
    <Resume />
  )
}

export default ResumeRouter