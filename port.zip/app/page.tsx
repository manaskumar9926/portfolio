import Resume from '@/components/resume'
import React from 'react'

const page = () => {
  return (
    <Resume />
  )
}

export default page