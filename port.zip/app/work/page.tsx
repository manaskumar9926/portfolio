import Work from '@/components/work'
import React from 'react'

const WorkRouter = () => {
  return (
    <Work />
  )
}

export default WorkRouter