import Contact from '@/components/contact'
import React from 'react'

const ContactRouter = () => {
  return (
    <Contact />
  )
}

export default ContactRouter